#include <signal.h>
#include <std_msgs/String.h>
#include <tf/transform_broadcaster.h>
#include "ros/ros.h"
#include <sensor_msgs/LaserScan.h>
#include <webots_ros/set_float.h>
#include <webots_ros/set_int.h>
#include <webots_ros/get_int.h>
#include <webots_ros/get_string.h>
#include <sensor_msgs/Imu.h>
#include <sensor_msgs/NavSatFix.h>

#define TIME_STEP 32
#define max_vel 2.5   
#define Factor_reductor 0.85

ros::NodeHandle *n;
ros::ServiceClient timeStepClient;
webots_ros::set_int timeStepSrv;

static int controllerCount;
static std::vector<std::string> controllerList;
//Motores definidos en el simuladores
static const char *motores[4] = {"rueda_id", "rueda_dd", "rueda_it", "rueda_dt"};
//Configuracion Lidar
static std::vector<float> ValoresLidar;
static int lidarResolucion = 0;
static int mitadResolucion = 0;
static double maxRango = 0.0;
static double rango_considerado = 0.0;
//Configuracion IMU
static double ImuValores[4] = {0, 0, 0, 0};
//Configuracion GPS
static double GPSValores[3] = {0, 0, 0};
//Parametros movimiento del robot
static double vel_lineal = 0.0;
static double vel_angular = 0.0;
static double vLeft = 0.0;
static double vRight = 0.0;
static double wLeft = 0.0;
static double wRight = 0.0;
static double r = 0.11;    //Radio de las ruedas en m
static double b = 0.38;    //Distancia entre ruedas a lo ancho



//Cinematica
void updateSpeed() {

  double speeds[4];

if(vel_lineal > 0.7) {
      vel_lineal = 0.7;
      }
      if(vel_angular > 2.44) {
      vel_angular = 2.44;
      }
      if(vel_lineal < -0.7){
      vel_lineal = -0.7;
     }
      if(vel_angular < -2.44){
      vel_angular = -2.44;
      }
    
    vLeft = vel_lineal  - b/2*vel_angular;      //Ruedas izquierda
    vRight = vel_lineal  + b/2*vel_angular;     //Ruedas derecha
    wLeft = vLeft  / r;
    wRight = vRight  / r;
    
    speeds[0] = wLeft;
    speeds[1] = wRight;
    speeds[2] = wLeft;
    speeds[3] = wRight;
  
  // set speeds
  for (int i = 0; i < 4; ++i) {
    ros::ServiceClient set_velocity_client;
    webots_ros::set_float set_velocity_srv;
    set_velocity_client = n->serviceClient<webots_ros::set_float>(std::string("pioneer2at/") + std::string(motores[i]) + std::string("/set_velocity"));
    set_velocity_srv.request.value = speeds[i];
    set_velocity_client.call(set_velocity_srv);
  }
}

void BroadcastTf() {
//TF
static tf::TransformBroadcaster br;
  tf::Transform transform;
 transform.setOrigin(tf::Vector3(GPSValores[0], GPSValores[2], GPSValores[1])); //Correspondencia con ejes en la simulacion, a partir de los msg de ROS.
 //transform.setOrigin(tf::Vector3(-GPSValores[2], GPSValores[0], GPSValores[1])); //Correspondencia con ejes en la simulacion, a partir de los msg de ROS.
 tf::Quaternion q(ImuValores[0], ImuValores[1], ImuValores[2], ImuValores[3]);

  q = q.inverse();
  transform.setRotation(q);
  br.sendTransform(tf::StampedTransform(transform, ros::Time::now(), "odom", "base_link"));
  tf::Quaternion x(0,0,0,1);
  x = x.inverse();
  transform.setOrigin(tf::Vector3(0.139, 0, 0.354)); 
  //transform.setOrigin(tf::Vector3(0, 0, 0));  //Posicion para la mejor visualizacion de los puntos escaneados sobre rviz
  transform.setRotation(x);
  //transform.setIdentity();
  br.sendTransform(tf::StampedTransform(transform, ros::Time::now(), "base_link", "pioneer2at/Sick_LMS_291"));

}


void lidarCallback(const sensor_msgs::LaserScan::ConstPtr &scan) {
  int scanSize = scan->ranges.size();
  ValoresLidar.resize(scanSize);
  for (int i = 0; i < scanSize; ++i)
    ValoresLidar[i] = scan->ranges[i];

  lidarResolucion = scanSize;
  mitadResolucion = scanSize / 2;
  maxRango = scan->range_max;
  rango_considerado = maxRango / 20.0;
 
}

void VelCallback(const geometry_msgs::Twist::ConstPtr &command){
 vel_lineal = command->linear.x;
 vel_angular = command->angular.z;
 updateSpeed();

}

void GPSCallback(const sensor_msgs::NavSatFix::ConstPtr &values) {
  GPSValores[0] = values->latitude; //x del mundo de webots en coordenadas locales
  GPSValores[1] = values->altitude; //z del mundo de webots en coordenadas locales
  GPSValores[2] = values->longitude; // y del mundo de webots en coordenadas locales
  
  BroadcastTf();
}

void ImuCallback(const sensor_msgs::Imu::ConstPtr &values) {

  ImuValores[0] = values->orientation.x;
  ImuValores[1] = values->orientation.y;
  ImuValores[2] = values->orientation.z;
  ImuValores[3] = values->orientation.w;
  BroadcastTf();
}


// catch names of the controllers availables on ROS network
void controllerNameCallback(const std_msgs::String::ConstPtr &name) {
  controllerCount++;
  controllerList.push_back(name->data);
  ROS_INFO("Controller #%d: %s.", controllerCount, controllerList.back().c_str());
}

void quit(int sig) {
  ROS_INFO("User stopped the 'pioneer2at' node.");
  timeStepSrv.request.value = 0;
  timeStepClient.call(timeStepSrv);
  ros::shutdown();
  exit(0);
}

int main(int argc, char **argv) {
  std::string controllerName;
  // create a node named 'pioneer2at' on ROS network
  ros::init(argc, argv, "pioneer2at", ros::init_options::AnonymousName);
  n = new ros::NodeHandle;

signal(SIGINT, quit);

  // subscribe to the topic model_name to get the list of availables controllers
  ros::Subscriber nameSub = n->subscribe("model_name", 100, controllerNameCallback);
  while (controllerCount == 0 || controllerCount < nameSub.getNumPublishers()) {
    ros::spinOnce();
    ros::spinOnce();
    ros::spinOnce();
  }
  ros::spinOnce();

  timeStepClient = n->serviceClient<webots_ros::set_int>("pioneer2at/robot/time_step");
  timeStepSrv.request.value = TIME_STEP;

// if there is more than one controller available, it let the user choose
  if (controllerCount == 1)
    controllerName = controllerList[0];
  else {
    int wantedController = 0;
    std::cout << "Choose the # of the controller you want to use:\n";
    std::cin >> wantedController;
    if (1 <= wantedController && wantedController <= controllerCount)
      controllerName = controllerList[wantedController - 1];
    else {
      ROS_ERROR("Invalid number for controller choice.");
      return 1;
    }
  }
  ROS_INFO("Using controller: '%s'", controllerName.c_str());
  // leave topic once it is not necessary anymore
  nameSub.shutdown();

ros::Subscriber cmd_vel = n->subscribe("/pioneer2at/vel", 100, VelCallback);

 // inicializacion de los motores
  for (int i = 0; i < 4; ++i) {
    // posicion
    ros::ServiceClient set_position_client;
    webots_ros::set_float set_position_srv;
    set_position_client = n->serviceClient<webots_ros::set_float>(std::string("pioneer2at/") + std::string(motores[i]) + std::string("/set_position"));

    set_position_srv.request.value = INFINITY;
    if (set_position_client.call(set_position_srv) && set_position_srv.response.success)
      ROS_INFO("Position set to INFINITY for motor %s.", motores[i]);
    else
      ROS_ERROR("Failed to call service set_position on motor %s.", motores[i]);

    // Velocidad
    ros::ServiceClient set_velocity_client;
    webots_ros::set_float set_velocity_srv;
    set_velocity_client = n->serviceClient<webots_ros::set_float>(std::string("pioneer2at/") +     std::string(motores[i]) + std::string("/set_velocity"));
    set_velocity_srv.request.value = 0.0;
    if (set_velocity_client.call(set_velocity_srv) && set_velocity_srv.response.success == 1)
      ROS_INFO("Velocity set to 0.0 for motor %s.", motores[i]);
    else
      ROS_ERROR("Failed to call service set_velocity on motor %s.", motores[i]);
  }

 // Inicializacion Lidar
  ros::ServiceClient set_lidar_client;
  webots_ros::set_int lidar_srv;
  ros::Subscriber sub_lidar_scan;

  set_lidar_client = n->serviceClient<webots_ros::set_int>("pioneer2at/Sick_LMS_291/enable");
  lidar_srv.request.value = TIME_STEP;
  if (set_lidar_client.call(lidar_srv) && lidar_srv.response.success) {
    ROS_INFO("Lidar enabled.");
    sub_lidar_scan = n->subscribe("pioneer2at/Sick_LMS_291/laser_scan/layer0", 10, lidarCallback);
    ROS_INFO("Topic for lidar initialized.");
    while (sub_lidar_scan.getNumPublishers() == 0) {
    }
    ROS_INFO("Topic for lidar scan connected.");
  } else {
    if (!lidar_srv.response.success)
      ROS_ERROR("Sampling period is not valid.");
    ROS_ERROR("Failed to enable lidar.");
    return 1;
  }



//Inicializacion IMU. Obtencion de la orientacion respecto al mundo.

  ros::ServiceClient set_inertial_unit_client;
  webots_ros::set_int inertial_unit_srv;
  ros::Subscriber sub_inertial_unit;
  set_inertial_unit_client = n->serviceClient<webots_ros::set_int>("pioneer2at/inertial_unit/enable");
  inertial_unit_srv.request.value = 32;
  if (set_inertial_unit_client.call(inertial_unit_srv) && inertial_unit_srv.response.success) {
    sub_inertial_unit = n->subscribe("pioneer2at/inertial_unit/roll_pitch_yaw", 1, ImuCallback);
    while (sub_inertial_unit.getNumPublishers() == 0) {
    }
    ROS_INFO("Inertial unit enabled.");
  } else {
    if (!inertial_unit_srv.response.success)
      ROS_ERROR("Sampling period is not valid.");
    ROS_ERROR("Failed to enable inertial unit.");
    return 1;
  }

//Inicializacion GPS. Obtencion de la posicion global
  // enable gps
  ros::ServiceClient set_GPS_client;
  webots_ros::set_int GPS_srv;
  ros::Subscriber sub_GPS;
  set_GPS_client = n->serviceClient<webots_ros::set_int>("pioneer2at/gps/enable");
  GPS_srv.request.value = 32;
  if (set_GPS_client.call(GPS_srv) && GPS_srv.response.success) {
    sub_GPS = n->subscribe("pioneer2at/gps/values", 1, GPSCallback);
    while (sub_GPS.getNumPublishers() == 0) {
    }
    ROS_INFO("GPS enabled.");
  } else {
    if (!GPS_srv.response.success)
      ROS_ERROR("Sampling period is not valid.");
    ROS_ERROR("Failed to enable GPS.");
    return 1;
  }

// main loop
  while (ros::ok()) {
    if (!timeStepClient.call(timeStepSrv) || !timeStepSrv.response.success) {
      ROS_ERROR("Failed to call service time_step for next step.");
      break;
    }
    ros::spinOnce();
  }
  timeStepSrv.request.value = 0;
  timeStepClient.call(timeStepSrv);

  ros::shutdown();
  return 0;
}



